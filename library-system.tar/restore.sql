--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.6 (Debian 14.6-1.pgdg110+1)
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "online-library-system";
--
-- Name: online-library-system; Type: DATABASE; Schema: -; Owner: db-user-foula
--

CREATE DATABASE "online-library-system" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "online-library-system" OWNER TO "db-user-foula";

\connect -reuse-previous=on "dbname='online-library-system'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: db-user-foula
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO "db-user-foula";

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: db-user-foula
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: author; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.author (
    id integer NOT NULL,
    name character varying NOT NULL,
    birth_date date NOT NULL,
    gender character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.author OWNER TO "db-user-foula";

--
-- Name: author_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.author_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.author_id_seq OWNER TO "db-user-foula";

--
-- Name: author_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.author_id_seq OWNED BY public.author.id;


--
-- Name: book; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.book (
    id integer NOT NULL,
    name character varying NOT NULL,
    number_of_pages integer NOT NULL,
    price integer NOT NULL,
    release_date date NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.book OWNER TO "db-user-foula";

--
-- Name: book_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.book_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.book_id_seq OWNER TO "db-user-foula";

--
-- Name: book_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.book_id_seq OWNED BY public.book.id;


--
-- Name: books_authors; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.books_authors (
    book_id integer NOT NULL,
    author_id integer NOT NULL
);


ALTER TABLE public.books_authors OWNER TO "db-user-foula";

--
-- Name: books_categories; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.books_categories (
    book_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.books_categories OWNER TO "db-user-foula";

--
-- Name: category; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.category (
    id integer NOT NULL,
    name character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.category OWNER TO "db-user-foula";

--
-- Name: category_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_id_seq OWNER TO "db-user-foula";

--
-- Name: category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.category_id_seq OWNED BY public.category.id;


--
-- Name: claim; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.claim (
    id integer NOT NULL,
    claim_name character varying NOT NULL,
    module_name character varying NOT NULL,
    read boolean NOT NULL,
    "create" boolean NOT NULL,
    update boolean NOT NULL,
    delete boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.claim OWNER TO "db-user-foula";

--
-- Name: claim_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.claim_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.claim_id_seq OWNER TO "db-user-foula";

--
-- Name: claim_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.claim_id_seq OWNED BY public.claim.id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.role (
    id integer NOT NULL,
    name character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.role OWNER TO "db-user-foula";

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_seq OWNER TO "db-user-foula";

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: roles_claims; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.roles_claims (
    role_id integer NOT NULL,
    claim_id integer NOT NULL
);


ALTER TABLE public.roles_claims OWNER TO "db-user-foula";

--
-- Name: user; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    email character varying NOT NULL,
    phone character varying NOT NULL,
    password character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    role_id integer
);


ALTER TABLE public."user" OWNER TO "db-user-foula";

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO "db-user-foula";

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: users_profiles; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.users_profiles (
    id integer NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    gender character varying NOT NULL,
    address character varying NOT NULL,
    birth_date date NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    auth_user_id integer
);


ALTER TABLE public.users_profiles OWNER TO "db-user-foula";

--
-- Name: users_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.users_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_profiles_id_seq OWNER TO "db-user-foula";

--
-- Name: users_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.users_profiles_id_seq OWNED BY public.users_profiles.id;


--
-- Name: author id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.author ALTER COLUMN id SET DEFAULT nextval('public.author_id_seq'::regclass);


--
-- Name: book id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.book ALTER COLUMN id SET DEFAULT nextval('public.book_id_seq'::regclass);


--
-- Name: category id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.category ALTER COLUMN id SET DEFAULT nextval('public.category_id_seq'::regclass);


--
-- Name: claim id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.claim ALTER COLUMN id SET DEFAULT nextval('public.claim_id_seq'::regclass);


--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: users_profiles id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.users_profiles ALTER COLUMN id SET DEFAULT nextval('public.users_profiles_id_seq'::regclass);


--
-- Data for Name: author; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

\i $$PATH$$/3410.dat

--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

\i $$PATH$$/3408.dat

--
-- Data for Name: books_authors; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

\i $$PATH$$/3412.dat

--
-- Data for Name: books_categories; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

\i $$PATH$$/3411.dat

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

\i $$PATH$$/3406.dat

--
-- Data for Name: claim; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

\i $$PATH$$/3414.dat

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

\i $$PATH$$/3416.dat

--
-- Data for Name: roles_claims; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

\i $$PATH$$/3421.dat

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

\i $$PATH$$/3420.dat

--
-- Data for Name: users_profiles; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

\i $$PATH$$/3418.dat

--
-- Name: author_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.author_id_seq', 2, true);


--
-- Name: book_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.book_id_seq', 8, true);


--
-- Name: category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.category_id_seq', 6, true);


--
-- Name: claim_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.claim_id_seq', 12, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.role_id_seq', 2, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.user_id_seq', 7, true);


--
-- Name: users_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.users_profiles_id_seq', 7, true);


--
-- Name: claim PK_466b305cc2e591047fa1ce58f81; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.claim
    ADD CONSTRAINT "PK_466b305cc2e591047fa1ce58f81" PRIMARY KEY (id);


--
-- Name: author PK_5a0e79799d372fe56f2f3fa6871; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.author
    ADD CONSTRAINT "PK_5a0e79799d372fe56f2f3fa6871" PRIMARY KEY (id);


--
-- Name: category PK_9c4e4a89e3674fc9f382d733f03; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT "PK_9c4e4a89e3674fc9f382d733f03" PRIMARY KEY (id);


--
-- Name: book PK_a3afef72ec8f80e6e5c310b28a4; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT "PK_a3afef72ec8f80e6e5c310b28a4" PRIMARY KEY (id);


--
-- Name: role PK_b36bcfe02fc8de3c57a8b2391c2; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT "PK_b36bcfe02fc8de3c57a8b2391c2" PRIMARY KEY (id);


--
-- Name: user PK_cace4a159ff9f2512dd42373760; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY (id);


--
-- Name: books_categories PK_dd273b23cf830ed55de0c199393; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_categories
    ADD CONSTRAINT "PK_dd273b23cf830ed55de0c199393" PRIMARY KEY (book_id, category_id);


--
-- Name: roles_claims PK_e267ebd3f54b40defb6ce005625; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.roles_claims
    ADD CONSTRAINT "PK_e267ebd3f54b40defb6ce005625" PRIMARY KEY (role_id, claim_id);


--
-- Name: users_profiles PK_e7a7f7db3fc96700d9239e43cda; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.users_profiles
    ADD CONSTRAINT "PK_e7a7f7db3fc96700d9239e43cda" PRIMARY KEY (id);


--
-- Name: books_authors PK_ec21802e4c7a8a22887600d7709; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_authors
    ADD CONSTRAINT "PK_ec21802e4c7a8a22887600d7709" PRIMARY KEY (book_id, author_id);


--
-- Name: users_profiles REL_28ba334a6a52cc5dac34e082ac; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.users_profiles
    ADD CONSTRAINT "REL_28ba334a6a52cc5dac34e082ac" UNIQUE (auth_user_id);


--
-- Name: IDX_68abbeb9a2e069557a635fb8ce; Type: INDEX; Schema: public; Owner: db-user-foula
--

CREATE INDEX "IDX_68abbeb9a2e069557a635fb8ce" ON public.roles_claims USING btree (role_id);


--
-- Name: IDX_738bc3574491eddb6cdd06896c; Type: INDEX; Schema: public; Owner: db-user-foula
--

CREATE INDEX "IDX_738bc3574491eddb6cdd06896c" ON public.books_authors USING btree (author_id);


--
-- Name: IDX_a3da1b2593720b806144c065cb; Type: INDEX; Schema: public; Owner: db-user-foula
--

CREATE INDEX "IDX_a3da1b2593720b806144c065cb" ON public.roles_claims USING btree (claim_id);


--
-- Name: IDX_a7267f91a94721a1b11c9a2f6a; Type: INDEX; Schema: public; Owner: db-user-foula
--

CREATE INDEX "IDX_a7267f91a94721a1b11c9a2f6a" ON public.books_categories USING btree (category_id);


--
-- Name: IDX_bf3c609a7c91bc032b805bbe14; Type: INDEX; Schema: public; Owner: db-user-foula
--

CREATE INDEX "IDX_bf3c609a7c91bc032b805bbe14" ON public.books_authors USING btree (book_id);


--
-- Name: IDX_ed5b61edeb35368078e032f5ca; Type: INDEX; Schema: public; Owner: db-user-foula
--

CREATE INDEX "IDX_ed5b61edeb35368078e032f5ca" ON public.books_categories USING btree (book_id);


--
-- Name: users_profiles FK_28ba334a6a52cc5dac34e082ac3; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.users_profiles
    ADD CONSTRAINT "FK_28ba334a6a52cc5dac34e082ac3" FOREIGN KEY (auth_user_id) REFERENCES public."user"(id);


--
-- Name: roles_claims FK_68abbeb9a2e069557a635fb8ce0; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.roles_claims
    ADD CONSTRAINT "FK_68abbeb9a2e069557a635fb8ce0" FOREIGN KEY (role_id) REFERENCES public.role(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: books_authors FK_738bc3574491eddb6cdd06896c6; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_authors
    ADD CONSTRAINT "FK_738bc3574491eddb6cdd06896c6" FOREIGN KEY (author_id) REFERENCES public.author(id);


--
-- Name: roles_claims FK_a3da1b2593720b806144c065cb4; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.roles_claims
    ADD CONSTRAINT "FK_a3da1b2593720b806144c065cb4" FOREIGN KEY (claim_id) REFERENCES public.claim(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: books_categories FK_a7267f91a94721a1b11c9a2f6a7; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_categories
    ADD CONSTRAINT "FK_a7267f91a94721a1b11c9a2f6a7" FOREIGN KEY (category_id) REFERENCES public.category(id);


--
-- Name: books_authors FK_bf3c609a7c91bc032b805bbe14d; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_authors
    ADD CONSTRAINT "FK_bf3c609a7c91bc032b805bbe14d" FOREIGN KEY (book_id) REFERENCES public.book(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: books_categories FK_ed5b61edeb35368078e032f5ca2; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_categories
    ADD CONSTRAINT "FK_ed5b61edeb35368078e032f5ca2" FOREIGN KEY (book_id) REFERENCES public.book(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user FK_fb2e442d14add3cefbdf33c4561; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "FK_fb2e442d14add3cefbdf33c4561" FOREIGN KEY (role_id) REFERENCES public.role(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: db-user-foula
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

